#include "Weiche.h"

void Weiche::begin()
{
    pinMode(m_pinGerade, OUTPUT);
    pinMode(m_pinAbzweig, OUTPUT);
    digitalWrite(m_pinGerade, HIGH);
    digitalWrite(m_pinAbzweig, HIGH);

    if (m_pinRed != 255) {
        pinMode(m_pinRed, OUTPUT);
        digitalWrite(m_pinRed, HIGH);
    }

    m_phase = IDLE;
}

void Weiche::schalte(Stellung ziel)
{
    m_soll = ziel;

    if (m_phase != IDLE)
        return;  // Impuls läuft → später

    startImpuls();
}

void Weiche::startImpuls()
{
    // aktivieren
    if (m_soll == GERADE) {
        digitalWrite(m_pinGerade, LOW);
        digitalWrite(m_pinAbzweig, HIGH);
    } else {
        digitalWrite(m_pinAbzweig, LOW);
        digitalWrite(m_pinGerade, HIGH);
    }

    m_phaseStart = millis();
    m_phase = IMPULS;
}

void Weiche::endImpuls()
{
    digitalWrite(m_pinGerade, HIGH);
    digitalWrite(m_pinAbzweig, HIGH);

    m_ist = m_soll;

    m_phaseStart = millis();
    m_phase = COOL;
}

bool Weiche::rueckmeldungAbzweig() const
{
    if (!m_rueckmelder) return false;
    return m_rueckmelder->read();
}

void Weiche::updateRed()
{
    if (m_pinRed == 255) return;

    // LOW = Reduktion aktiv
    bool aktiv = rueckmeldungAbzweig();
    digitalWrite(m_pinRed, aktiv ? LOW : HIGH);
}

void Weiche::update(uint32_t now)
{
    switch (m_phase)
    {
        case IDLE:
            break;

        case IMPULS:
            if (now - m_phaseStart >= IMPULS_MS)
                endImpuls();
            break;

        case COOL:
            if (now - m_phaseStart >= COOL_MS)
                m_phase = IDLE;
            break;
    }

    updateRed();
}
