#include "mega_frame.h"
#include <string.h>

// Falls du globale Projekteinstellungen nutzt:
extern uint16_t g_weichenIst;   
extern uint16_t g_weichenSoll;
extern uint16_t g_sensorBits;

void buildStatusFrame(uint8_t* buf, MegaId id)
{
    static uint8_t heartbeat = 0;
    heartbeat++;

    buf[0]  = MEGA_FRAME_HEADER;
    buf[1]  = MEGA_FRAME_VERSION;
    buf[2]  = (uint8_t)MegaMsgType::STATUS;
    buf[3]  = MEGA_FRAME_LENGTH;

    buf[4]  = (uint8_t)id;       // MEGA1
    buf[5]  = heartbeat;

    buf[6]  = 0; // ERROR_FLAGS  -> später
    buf[7]  = 0; // WARN_FLAGS   -> später
    buf[8]  = 0; // STATE_FLAGS  -> später
    buf[9]  = 0; // DR_STATE     -> später

    // Sensorbits (vorerst Dummy oder echte Bits)
    uint16_t sensor = g_sensorBits;  
    buf[10] = sensor & 0xFF;
    buf[11] = sensor >> 8;

    // Weichen IST
    buf[12] = g_weichenIst & 0xFF;
    buf[13] = g_weichenIst >> 8;

    // Weichen SOLL
    buf[14] = g_weichenSoll & 0xFF;
    buf[15] = g_weichenSoll >> 8;

    // Analogwerte (Mega1 = nicht benötigt → 0)
    buf[16] = 0;
    buf[17] = 0;
    buf[18] = 0;
    buf[19] = 0;

    // Alte Reserven (Bytes 20–23)
    buf[20] = buf[21] = buf[22] = buf[23] = 0;

    // LIGHT_DATA[8]
    memset(&buf[24], 0, 8);

    // MODULE_STATE[4]
    memset(&buf[32], 0, 4);

    // USER_DATA[3]
    memset(&buf[36], 0, 3);

    // Checksum (Byte 39)
    buf[39] = mega_calcChecksum(buf, 39);
}
