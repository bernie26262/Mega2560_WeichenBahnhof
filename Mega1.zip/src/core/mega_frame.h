#pragma once
#include <Arduino.h>
#include "mega_proto.h"

void buildStatusFrame(uint8_t* buf, MegaId id);
