#include "proto_mega1.h"

size_t buildMega1StatusFrame(uint8_t* outBuf, const Mega1StatusPayload& p)
{
    ProtoHeader h;
    h.slaveId    = SlaveId::MEGA1;
    h.msgType    = MsgType::STATUS;
    h.payloadLen = sizeof(Mega1StatusPayload);

    // Header schreiben
    proto_writeHeader(outBuf, h);

    // Payload kopieren
    const uint8_t* payloadBytes = reinterpret_cast<const uint8_t*>(&p);

    const size_t headerSize = 5;   // Magic, Ver, SlaveID, MsgType, PayloadLen
    for (size_t i = 0; i < sizeof(Mega1StatusPayload); ++i)
        outBuf[headerSize + i] = payloadBytes[i];

    // Checksumme
    size_t lenWithoutChecksum = headerSize + sizeof(Mega1StatusPayload);
    outBuf[lenWithoutChecksum] = proto_calcChecksum(outBuf, lenWithoutChecksum);

    return lenWithoutChecksum + 1;
}
