#include "BahnhofController.h"
#include "SensorHub.h"

extern SensorHub sensorHub;

void BahnhofController::begin()
{
    memset(m_state, 0, sizeof(m_state));
    memset(m_fahrstr, 0, sizeof(m_fahrstr));
    memset(m_einfahrtEvent, 0, sizeof(m_einfahrtEvent));
}

void BahnhofController::update(uint32_t now)
{
    // Bahnhöfe 0 & 1 → Einfahrt über S2
    checkBhf(0, 2);
    checkBhf(1, 2);

    // Bahnhöfe 2 & 3 → Einfahrt über S8
    checkBhf(2, 8);
    checkBhf(3, 8);

    // Timerstart wird vom Payload-Build erledigt
}

void BahnhofController::checkBhf(uint8_t bhf, uint8_t sensorEinfahrt)
{
    bool active = sensorHub.isActive(sensorEinfahrt);

    if (active)
    {
        m_state[bhf] = 1;        // z.B. „Zug an Bahnhofs-Einfahrt“
        m_einfahrtEvent[bhf] = true;
    }
    else
    {
        m_einfahrtEvent[bhf] = false;
    }

    // Fahrstraße oder weitere Logik kann hier ergänzt werden
}
