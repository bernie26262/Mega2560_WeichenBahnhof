#include <Arduino.h>
#include <Wire.h>

#include "mega1_pins.h"
#include "proto_mega1.h"

#include "SensorHub.h"
#include "WeichenHub.h"
#include "BahnhofController.h"
#include "Fahrstrassen.h"
#include "Modus.h"

// Globale Objekte
SensorHub         sensorHub;
WeichenHub        weichenHub;
BahnhofController bfController;
Fahrstrassen      fahrstrassen;
ModusController   modusController;

Mega1StatusPayload g_payload;
volatile bool g_payloadDirty = false;

uint16_t g_bootId = 0;


// ===========================================================
//   Bahnhof-Bits aus Controller ableiten
// ===========================================================

uint8_t buildBhfKontaktBits()
{
    uint8_t bits = 0;

    for (uint8_t i = 0; i < 4; i++)
        if (bfController.einfahrtDetected(i))
            bits |= (1 << i);

    return bits;
}

uint8_t buildBhfTimerBits()
{
    uint8_t bits = 0;

    if (sensorHub.isActive(19)) bits |= 0x01; // Bhf0
    if (sensorHub.isActive(18)) bits |= 0x02; // Bhf1
    if (sensorHub.isActive(22)) bits |= 0x04; // Bhf2
    if (sensorHub.isActive(23)) bits |= 0x08; // Bhf3

    return bits;
}


// ===========================================================
//   I2C
// ===========================================================

void onI2CRequest()
{
    Wire.write((uint8_t*)&g_payload, sizeof(g_payload));
    g_payloadDirty = false;
}

void onI2CReceive(int)
{
    while (Wire.available()) Wire.read();   
}


// ===========================================================
//   SETUP
// ===========================================================

void setup()
{
    Serial.begin(115200);
    delay(200);

    g_bootId = random(1, 65535);

    // --- Weichen registrieren ---
    for (uint8_t i = 0; i < NUM_WEICHEN; i++)
        weichenHub.attach(i, &g_weichen[i]);

    // --- Module starten ---
    sensorHub.begin();
    weichenHub.begin();
    bfController.begin();
    fahrstrassen.begin();
    modusController.begin();

    // Payload vorbereiten
    memset(&g_payload, 0, sizeof(g_payload));
    g_payload.bootId = g_bootId;

    // DataReady-Pin
    pinMode(PIN_DATA_READY_M1, OUTPUT);
    digitalWrite(PIN_DATA_READY_M1, LOW);

    // I2C
    Wire.begin(MEGA1_I2C_ADDRESS);
    Wire.onRequest(onI2CRequest);
    Wire.onReceive(onI2CReceive);

    Serial.println(F(">>> Mega1 betriebsbereit."));
}


// ===========================================================
//   LOOP – 10 ms Tick
// ===========================================================

uint32_t lastTick = 0;

void loop()
{
    uint32_t now = millis();
    if (now - lastTick < 10) return;
    lastTick = now;

    // --- Updates ---
    sensorHub.update(now);
    weichenHub.update(now);
    bfController.update(now);
    fahrstrassen.update(now);
    modusController.update();

    // --- Payload befüllen ---
    g_payload.updateCounter++;
    g_payload.uptimeDiv100 = now / 100;

    g_payload.modus = modusController.current() == MOD_AUTOMATIK ? 0 : 1;

    g_payload.statusFlags =
        (g_payload.modus == 0 ? STATUS_AUTOMATIK : STATUS_MANUELL);

    // SensorHub
    g_payload.kontaktBits = sensorHub.kontaktBits();

    for (uint8_t i = 0; i < MEGA1_MAX_SENS; i++)
        g_payload.triggerCount[i] = sensorHub.triggerCount(i);

    // Weichen
    g_payload.weichenIst        = weichenHub.istBits();
    g_payload.weichenSoll       = weichenHub.sollBits();
    g_payload.weichenReduktion  = weichenHub.redBits();

    // Fahrstraßen
    g_payload.aktiveFahrstrasse = fahrstrassen.activeIndex();
    g_payload.fahrstrState      = fahrstrassen.state();

    // Bahnhofszustände
    for (uint8_t i = 0; i < 4; i++)
    {
        g_payload.bhfState[i]   = bfController.state(i);
        g_payload.bhfFahrstr[i] = bfController.fahrstr(i);
    }

    // NEU: Bahnhof-Bits
    g_payload.bhfKontaktBits = buildBhfKontaktBits();
    g_payload.bhfTimerBits   = buildBhfTimerBits();

    // DataReady kurz pulsen
    digitalWrite(PIN_DATA_READY_M1, HIGH);
    delayMicroseconds(200);
    digitalWrite(PIN_DATA_READY_M1, LOW);

    g_payloadDirty = true;
}
