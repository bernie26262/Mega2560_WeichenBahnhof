#include "SteuerungWeichen.h"
#include "EventQueue.h"
#include "debug.h"

// Nummer der Fahrstraßen kommt aus config.cpp
extern const uint8_t NUM_STW_FS;

// Counter-Arrays hier dimensionieren
uint32_t fsStatsCount[]    = {0,0,0,0,0};  // Statistik
uint16_t fsPassageCount[]  = {0,0,0,0,0};  // Überfahrten

SteuerungWeichen::SteuerungWeichen(
    Weiche* arr,
    const SteuerungWeichenDefinition* defs,
    uint8_t numFs
)
: _weichen(arr),
  _defs(defs),
  _numFs(numFs)
{
}

// Prüfe ob Sensor ein Reset-Sensor der FS ist
bool SteuerungWeichen::isResetSensor(const SteuerungWeichenDefinition& fs, uint8_t sensor)
{
    for (uint8_t i = 0; i < fs.numReset; i++) {
        if (fs.resetSensors[i] == sensor)
            return true;
    }
    return false;
}

void SteuerungWeichen::onSensorTrigger(uint8_t sIdx)
{
    for (uint8_t fsIndex = 0; fsIndex < _numFs; fsIndex++) {

        const SteuerungWeichenDefinition& fs = _defs[fsIndex];

        // Start-Sensor?
        if (sIdx == fs.sensorIndex) {
            startFs(fsIndex);
        }

        // Reset-Sensoren?
        if (isResetSensor(fs, sIdx)) {
            fsPassageCount[fsIndex] = 0;
            pushEvent(EVT_FS_COUNTER, fsIndex, 0);
            DBGLN(String("[FS] Reset FS ") + fsIndex);
        }
    }
}

void SteuerungWeichen::startFs(uint8_t fsIndex)
{
    if (fsIndex >= _numFs) return;

    const SteuerungWeichenDefinition& fs = _defs[fsIndex];

    DBGLN(String("[FS] Starte FS=") + fsIndex);

    // Statistik erhöhen
    fsStatsCount[fsIndex]++;

    // Überfahrten erhöhen
    fsPassageCount[fsIndex]++;

    // Event an ESP senden
    pushEvent(EVT_FS_COUNTER, fsIndex, fsPassageCount[fsIndex]);

    // Schritte abarbeiten
    for (uint8_t i = 0; i < fs.numSteps; i++) {
        const WeichenSchaltSchritt& step = fs.steps[i];

        // minCounter-Regel berücksichtigen
        if (fsPassageCount[fsIndex] >= step.minCounter) {
            uint8_t wid = step.index;
            _weichen[wid].ziel = step.richtung;
            _weichen[wid].schalten();
        }
    }
}
