#include "Bahnhof.h"

Bahnhof::Bahnhof()
: _index(255),
  _stromPin(255),
  _sensorEinfahrt(255),
  _sensorTimerStart(255),
  _haltezeit(0),
  _timerAktiv(false),
  _timerStart(0),
  _stromAn(false)
{}

void Bahnhof::configure(const BahnhofConfig &cfg, uint8_t index) {
    _index            = index;
    _stromPin         = cfg.stromPin;
    _sensorEinfahrt   = cfg.sensorEinfahrt;
    _sensorTimerStart = cfg.sensorTimerStart;
    _haltezeit        = cfg.haltezeitMs;
}

void Bahnhof::begin() {
    if (_stromPin == 255) return;

    pinMode(_stromPin, OUTPUT);
    digitalWrite(_stromPin, HIGH);   // Relais AUS → Strom AUS
    _stromAn = false;
}

void Bahnhof::setStrom(bool an) {
    if (_stromPin == 255) return;

    digitalWrite(_stromPin, an ? LOW : HIGH);   // low-aktiv
    _stromAn = an;

    pushEvent(EVT_BHF, _index, (an ? 1 : 0));
}

void Bahnhof::handleSensor(uint8_t sIdx, Betriebsmodus mode) {
    if (mode != MOD_AUTOMATIK) return;

    // Zug fährt ein → sofort stromlos
    if (sIdx == _sensorEinfahrt) {
        DBGLN(String("Bahnhof ") + _index + ": Einfahrt → Strom AUS");
        setStrom(false);
    }

    // Abfahrtstimer starten
    if (sIdx == _sensorTimerStart) {
        DBGLN(String("Bahnhof ") + _index + ": Timerstart");
        _timerAktiv  = true;
        _timerStart  = millis();
    }
}

void Bahnhof::update(Betriebsmodus mode) {
    if (_stromPin == 255) return;

    // Manueller Modus → Strom immer AN, kein Timer
    if (mode == MOD_MANUELL) {
        if (!_timerAktiv) setStrom(true);
        _timerAktiv = false;
        return;
    }

    // Automatik: Timer anwenden
    if (_timerAktiv) {
        unsigned long now = millis();
        if (now - _timerStart >= _haltezeit) {
            DBGLN(String("Bahnhof ") + _index + ": Abfahrt → Strom AN");
            setStrom(true);
            _timerAktiv = false;
        }
    }
}
