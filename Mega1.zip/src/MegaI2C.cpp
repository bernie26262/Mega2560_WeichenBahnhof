// src/MegaI2C.cpp
#include "MegaI2C.h"

#include <Wire.h>
#include "config.h"
#include "core/proto_common.h"
#include "core/proto_mega1.h"

// Globale Payload aus main.cpp
extern Mega1StatusPayload g_payload;
extern volatile bool g_payloadDirty;

// I2C-Request-Handler (ESP32 liest Status-Frame)
static void onI2CRequest();

void megaI2C_begin() {
    // DataReady-Pin initial auf LOW
    pinMode(PIN_I2C_INT, OUTPUT);
    digitalWrite(PIN_I2C_INT, LOW);

    // Mega1 als I2C-Slave
    Wire.begin(I2C_SLAVE_ADDR);
    Wire.onRequest(onI2CRequest);
}

void megaI2C_update() {
    // DataReady-Pin signalisiert dem ESP32, dass neue Daten vorliegen
    digitalWrite(PIN_I2C_INT, g_payloadDirty ? HIGH : LOW);

    // Platz für spätere Erweiterungen (Watchdog, Statistiken, ...)
}

// Wird aufgerufen, wenn der ESP32 Daten vom Mega1 anfordert
static void onI2CRequest() {
    uint8_t buffer[PROTO_MAX_FRAME_SIZE];
    size_t len = buildMega1StatusFrame(buffer, g_payload);

    Wire.write(buffer, len);

    // Nach dem Senden ist der aktuelle Payload "abgeholt"
    g_payloadDirty = false;
    digitalWrite(PIN_I2C_INT, LOW);
}
