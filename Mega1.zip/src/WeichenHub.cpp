#include "WeichenHub.h"

WeichenHub weichenHub;

void WeichenHub::begin()
{
    for (uint8_t i = 0; i < MAX; i++)
        if (m_w[i]) m_w[i]->begin();
}

void WeichenHub::attach(uint8_t idx, Weiche* w)
{
    if (idx < MAX)
        m_w[idx] = w;
}

void WeichenHub::update(uint32_t now)
{
    m_istBits = 0;
    m_sollBits = 0;
    m_redBits = 0;

    for (uint8_t i = 0; i < MAX; i++)
    {
        Weiche* w = m_w[i];
        if (!w) continue;

        w->update(now);

        if (w->ist() == Weiche::ABBIEGEN)
            m_istBits |= (1 << i);

        if (w->soll() == Weiche::ABBIEGEN)
            m_sollBits |= (1 << i);

        if (w->rueckmeldungAbzweig())
            m_redBits |= (1 << i);
    }
}
