#include "SensorHub.h"

// Globales Objekt
SensorHub sensorHub;

// ------------------------------------------------------------
// Pin-Zuordnung für alle Sensoren 0..23
// ------------------------------------------------------------
// Wir verwenden 255 (= kein Pin) als "nicht belegt".

static const uint8_t SENSOR_PIN[MEGA1_MAX_SENS] = {
    PIN_S0,   // 0
    PIN_S1,   // 1
    PIN_S2,   // 2
    PIN_S3,   // 3
    PIN_S4,   // 4
    PIN_S5,   // 5
    PIN_S6,   // 6
    PIN_S7,   // 7
    PIN_S8,   // 8
    PIN_S9,   // 9
    PIN_S10,  // 10

    255,      // 11 (frei)
    255,      // 12 (frei)
    255,      // 13 (frei)
    255,      // 14 (frei)
    255,      // 15 (frei)
    255,      // 16 (frei)
    255,      // 17 (frei)

    PIN_S18,  // 18
    PIN_S19,  // 19
    255,      // 20
    255,      // 21
    PIN_S22,  // 22
    PIN_S23   // 23
};

// Welche Sensoren sind PulseSensoren?
static const bool SENSOR_IS_PULSE[MEGA1_MAX_SENS] = {
    true, true, true, true, true, true, true, true, true, true, true,   // S0..S10
    false, false, false, false, false, false, false,                    // 11..17
    true, true, false, false, true, true                                // 18,19,20,21,22,23
};

// ------------------------------------------------------------
// INIT
// ------------------------------------------------------------

void SensorHub::begin()
{
    for (uint8_t i = 0; i < MAX; i++)
    {
        m_triggerCount[i] = 0;
        m_lastActive[i]   = false;
        m_typ[i] = SensorTyp::NONE;

        uint8_t pin = SENSOR_PIN[i];
        if (pin == 255)
            continue;

        if (SENSOR_IS_PULSE[i]) {
            attachPulse(i, pin);
        } else {
            attachKontakt(i, pin);
        }
    }
}

// ------------------------------------------------------------
// UPDATE
// ------------------------------------------------------------

void SensorHub::update(uint32_t now)
{
    m_kontaktBits = 0;

    for (uint8_t id = 0; id < MAX; id++)
    {
        uint8_t pin = SENSOR_PIN[id];
        if (pin == 255) continue;

        bool active = false;

        if (m_typ[id] == SensorTyp::PULSE)
        {
            if (m_pulse[id].fell())
                m_triggerCount[id]++;

            active = (m_pulse[id].raw() == LOW);
        }
        else if (m_typ[id] == SensorTyp::KONTAKT)
        {
            active = m_kontakt[id].read();
            if (active && !m_lastActive[id])
                m_triggerCount[id]++;
        }

        if (active) m_kontaktBits |= (1UL << id);
        m_lastActive[id] = active;
    }
}

// ------------------------------------------------------------
// Helfer
// ------------------------------------------------------------

void SensorHub::attachPulse(uint8_t id, uint8_t pin)
{
    m_typ[id] = SensorTyp::PULSE;
    m_pulse[id].attach(pin);
    m_pulse[id].begin();
}

void SensorHub::attachKontakt(uint8_t id, uint8_t pin)
{
    m_typ[id] = SensorTyp::KONTAKT;
    m_kontakt[id].attach(pin);
    m_kontakt[id].begin();
}

bool SensorHub::isActive(uint8_t id) const
{
    return (m_kontaktBits & (1UL << id)) != 0;
}

bool SensorHub::fell(uint8_t id) const
{
    if (id >= MAX) return false;
    if (m_typ[id] != SensorTyp::PULSE) return false;
    return false;  // PulseSensor.fell() wird im Update erzeugt
}
