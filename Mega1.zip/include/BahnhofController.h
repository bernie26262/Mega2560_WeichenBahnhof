#pragma once
#include <Arduino.h>
#include "SensorHub.h"
#include "mega1_pins.h"

class BahnhofController
{
public:
    void begin();
    void update(uint32_t now);

    uint8_t state(uint8_t bhf) const { return m_state[bhf]; }
    uint8_t fahrstr(uint8_t bhf) const { return m_fahrstr[bhf]; }

    // Für Payload
    bool einfahrtDetected(uint8_t bhf) const { return m_einfahrtEvent[bhf]; }

private:
    uint8_t m_state[4]    = {0,0,0,0};
    uint8_t m_fahrstr[4]  = {0,0,0,0};

    bool m_einfahrtEvent[4] = {false,false,false,false};

    // interne Hilfsfunktionen
    void checkBhf(uint8_t bhf, uint8_t sensorEinfahrt);
};
