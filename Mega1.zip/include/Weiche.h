#pragma once
#include <Arduino.h>
#include "SensorKontakt.h"

class Weiche
{
public:
    enum Stellung : uint8_t {
        GERADE   = 0,
        ABBIEGEN = 1
    };

    Weiche() {}

    Weiche(uint8_t id,
           uint8_t pinGerade,
           uint8_t pinAbzweig,
           uint8_t pinRed,
           SensorKontakt* rueck)
        : m_id(id),
          m_pinGerade(pinGerade),
          m_pinAbzweig(pinAbzweig),
          m_pinRed(pinRed),
          m_rueckmelder(rueck)
    {}

    void begin();
    void update(uint32_t now);

    // API für Fahrstraßen / ESP
    void schalte(Stellung ziel);
    inline void setGerade()  { schalte(GERADE); }
    inline void setAbzweig() { schalte(ABBIEGEN); }

    Stellung soll() const { return m_soll; }
    Stellung ist()  const { return m_ist;  }

    bool rueckmeldungAbzweig() const;

    uint8_t id() const { return m_id; }

private:
    uint8_t m_id = 255;

    uint8_t m_pinGerade = 255;
    uint8_t m_pinAbzweig = 255;
    uint8_t m_pinRed = 255;       // LOW = Reduktion aktiv
    SensorKontakt* m_rueckmelder = nullptr;

    Stellung m_soll = GERADE;
    Stellung m_ist  = GERADE;

    enum Phase { IDLE, IMPULS, COOL };
    Phase m_phase = IDLE;

    uint32_t m_phaseStart = 0;
    static constexpr uint16_t IMPULS_MS  = 400;
    static constexpr uint16_t COOL_MS    = 800;

    void startImpuls();
    void endImpuls();
    void updateRed();
};
