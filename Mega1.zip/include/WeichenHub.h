#pragma once
#include <Arduino.h>
#include "Weiche.h"

class WeichenHub
{
public:
    static constexpr uint8_t MAX = 12;

    void begin();
    void update(uint32_t now);

    void attach(uint8_t idx, Weiche* w);

    uint16_t istBits() const { return m_istBits; }
    uint16_t sollBits() const { return m_sollBits; }
    uint16_t redBits() const { return m_redBits; }

private:
    Weiche* m_w[MAX] = { nullptr };

    uint16_t m_istBits  = 0;
    uint16_t m_sollBits = 0;
    uint16_t m_redBits  = 0;
};

extern WeichenHub weichenHub;
