#pragma once
#include <Arduino.h>
#include "PulseSensor.h"
#include "SensorKontakt.h"
#include "mega1_pins.h"

// ------------------------------------------------------------
// SensorTyp – damit der Hub weiß, welcher Sensor wie verarbeitet wird
// ------------------------------------------------------------
enum class SensorTyp : uint8_t {
    NONE = 0,
    PULSE,          // PulseSensor: fallende Flanke
    KONTAKT         // SensorKontakt: Low = aktiv
};

// ------------------------------------------------------------
// SensorHub – verwaltet bis zu 24 Sensoren (S0..S23)
//
// Features:
//  - PulseSensor oder KontaktSensor
//  - Triggerzähler pro Sensor
//  - kontaktBits (für I2C Payload)
//  - fell(id) → FALLING EDGE
// ------------------------------------------------------------

class SensorHub {
public:
    void begin();
    void update(uint32_t now);

    // Prüft den aktuellen Zustand (LOW=aktiv)
    bool isActive(uint8_t id) const;

    // Prüft fallende Flanke bei PulseSensor
    bool fell(uint8_t id) const;

    // Triggerzähler
    uint16_t triggerCount(uint8_t id) const { return m_triggerCount[id]; }

    // Kontaktbits für Payload (S0..S23 → Bits 0..23)
    uint32_t kontaktBits() const { return m_kontaktBits; }

private:
    // ---------------- interner Zustand ----------------
    static constexpr uint8_t MAX = MEGA1_MAX_SENS; // = 24

    SensorTyp     m_typ[MAX];
    PulseSensor   m_pulse[MAX];
    SensorKontakt m_kontakt[MAX];

    bool          m_lastActive[MAX];
    uint16_t      m_triggerCount[MAX];

    uint32_t      m_kontaktBits = 0;

    // interne Funktionen
    void attachPulse(uint8_t id, uint8_t pin);
    void attachKontakt(uint8_t id, uint8_t pin);
};

extern SensorHub sensorHub;
