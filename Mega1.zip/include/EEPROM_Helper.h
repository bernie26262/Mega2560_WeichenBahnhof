#pragma once
#include <Arduino.h>
#include <EEPROM.h>

// Nur auf ESP32/ESP8266 benötigt, aber harmlos auf AVR
inline void eepromCommitIfSupported() {
#if defined(ESP8266) || defined(ESP32)
    EEPROM.commit();
#endif
}

// Schreibt nur, wenn sich der Wert geändert hat
inline void eepromWriteIfChanged(int addr, uint8_t val) {
    uint8_t old = EEPROM.read(addr);
    if (old != val) {
        EEPROM.write(addr, val);
        eepromCommitIfSupported();
    }
}
