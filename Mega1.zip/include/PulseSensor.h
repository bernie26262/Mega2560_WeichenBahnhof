#pragma once
#include <Arduino.h>

// ------------------------------------------------------------
// PulseSensor (low-aktiv)
//
// Liefert TRUE genau bei der fallenden Flanke: HIGH → LOW.
// Basiert auf einem einfachen digitalen Input.
// ------------------------------------------------------------

class PulseSensor {
public:
    PulseSensor() {}
    PulseSensor(uint8_t pin) : m_pin(pin) {}

    void attach(uint8_t pin)
    {
        m_pin = pin;
    }

    void begin()
    {
        if (m_pin == 255) return;
        pinMode(m_pin, INPUT_PULLUP);
        m_last = digitalRead(m_pin);
    }

    bool fell()
    {
        if (m_pin == 255) return false;

        uint8_t raw = digitalRead(m_pin);
        bool event  = (m_last == HIGH && raw == LOW);
        m_last = raw;
        return event;
    }

    bool raw() const
    {
        return (m_pin == 255) ? HIGH : digitalRead(m_pin);
    }

private:
    uint8_t m_pin = 255;
    uint8_t m_last = HIGH;
};
