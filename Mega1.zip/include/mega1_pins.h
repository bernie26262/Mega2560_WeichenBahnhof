#pragma once
#include <Arduino.h>

/*
    =========================================================
      Mega1 – zentrale Pinbelegung (S0–S23, W0–W11, DataReady)
      Stand: nach Benutzerangabe vollständig rekonstruiert
    =========================================================
*/

// ---------------------------------------------------------
//  SCHALTGLEISE S0…S10  (PulseSensor, low-aktiv)
// ---------------------------------------------------------
constexpr uint8_t PIN_S0  = 22;
constexpr uint8_t PIN_S1  = 28;
constexpr uint8_t PIN_S2  = 23;
constexpr uint8_t PIN_S3  = 33;
constexpr uint8_t PIN_S4  = 24;
constexpr uint8_t PIN_S5  = 32;
constexpr uint8_t PIN_S6  = 25;
constexpr uint8_t PIN_S7  = 31;
constexpr uint8_t PIN_S8  = 27;
constexpr uint8_t PIN_S9  = 35;
constexpr uint8_t PIN_S10 = 34;

// ---------------------------------------------------------
//  TIMERSTART-SENSOREN (PulseSensor, low-aktiv)
//  Diese befinden sich an analogen Pins A8–A11
// ---------------------------------------------------------
constexpr uint8_t PIN_S18 = A9;   // Bhf 1 Timerstart
constexpr uint8_t PIN_S19 = A8;   // Bhf 0 Timerstart
constexpr uint8_t PIN_S22 = A10;  // Bhf 2 Timerstart
constexpr uint8_t PIN_S23 = A11;  // Bhf 3 Timerstart

// ---------------------------------------------------------
//  WEICHEN W0–W11
//  Jedes Objekt besitzt:
//     GERADE-Pin
//     ABBIEGEN-Pin
//     REDUKTION-Pin (low-aktiv, optional)
//     RÜCKMELDE-Pin
// ---------------------------------------------------------

// W0
constexpr uint8_t PIN_W0_G    = 5;
constexpr uint8_t PIN_W0_A    = 6;
constexpr uint8_t PIN_W0_RED  = 255;
constexpr uint8_t PIN_W0_RM   = 38;

// W1
constexpr uint8_t PIN_W1_G    = 8;
constexpr uint8_t PIN_W1_A    = 9;
constexpr uint8_t PIN_W1_RED  = 255;
constexpr uint8_t PIN_W1_RM   = 39;

// W2
constexpr uint8_t PIN_W2_G    = 10;
constexpr uint8_t PIN_W2_A    = 11;
constexpr uint8_t PIN_W2_RED  = 255;
constexpr uint8_t PIN_W2_RM   = 40;

// W3
constexpr uint8_t PIN_W3_G    = 12;
constexpr uint8_t PIN_W3_A    = 13;
constexpr uint8_t PIN_W3_RED  = 255;
constexpr uint8_t PIN_W3_RM   = 41;

// W4
constexpr uint8_t PIN_W4_G    = 14;
constexpr uint8_t PIN_W4_A    = 15;
constexpr uint8_t PIN_W4_RED  = 255;
constexpr uint8_t PIN_W4_RM   = 42;

// W5
constexpr uint8_t PIN_W5_G    = 16;
constexpr uint8_t PIN_W5_A    = 17;
constexpr uint8_t PIN_W5_RED  = 255;
constexpr uint8_t PIN_W5_RM   = 43;

// W6
constexpr uint8_t PIN_W6_G    = 18;
constexpr uint8_t PIN_W6_A    = 19;
constexpr uint8_t PIN_W6_RED  = A12;
constexpr uint8_t PIN_W6_RM   = 44;

// W7
constexpr uint8_t PIN_W7_G    = 2;
constexpr uint8_t PIN_W7_A    = 3;
constexpr uint8_t PIN_W7_RED  = A13;
constexpr uint8_t PIN_W7_RM   = 45;

// W8
constexpr uint8_t PIN_W8_G    = A0;
constexpr uint8_t PIN_W8_A    = A1;
constexpr uint8_t PIN_W8_RED  = A14;
constexpr uint8_t PIN_W8_RM   = 46;

// W9
constexpr uint8_t PIN_W9_G    = A2;
constexpr uint8_t PIN_W9_A    = A3;
constexpr uint8_t PIN_W9_RED  = A15;
constexpr uint8_t PIN_W9_RM   = 47;

// W10
constexpr uint8_t PIN_W10_G   = A4;
constexpr uint8_t PIN_W10_A   = A5;
constexpr uint8_t PIN_W10_RED = 50;   // gemeinsam mit W11
constexpr uint8_t PIN_W10_RM  = 48;

// W11
constexpr uint8_t PIN_W11_G   = A6;
constexpr uint8_t PIN_W11_A   = A7;
constexpr uint8_t PIN_W11_RED = 50;   // gemeinsam mit W10
constexpr uint8_t PIN_W11_RM  = 49;

// ---------------------------------------------------------
//  DATA READY PIN Mega1 → ESP32
// ---------------------------------------------------------
constexpr uint8_t PIN_DATA_READY_M1 = 51;

// ---------------------------------------------------------
//  I2C-Adresse Mega1
// ---------------------------------------------------------
constexpr uint8_t MEGA1_I2C_ADDRESS = 0x11;

