#pragma once
#include <Arduino.h>

#ifdef DEBUG_SERIAL
  #define DBG(x)        Serial.print(x)
  #define DBGLN(x)      Serial.println(x)
  #define DBGVAR(x)     do { Serial.print(#x " = "); Serial.println(x); } while(0)
#else
  #define DBG(x)        do{}while(0)
  #define DBGLN(x)      do{}while(0)
  #define DBGVAR(x)     do{}while(0)
#endif
