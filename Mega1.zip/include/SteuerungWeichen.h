#pragma once
#include <Arduino.h>
#include "Weiche.h"
#include "config.h"

// Counter werden NUR extern angekündigt
extern uint32_t fsStatsCount[];
extern uint16_t fsPassageCount[];

class SteuerungWeichen {

public:
    SteuerungWeichen(
        Weiche* arr,
        const SteuerungWeichenDefinition* defs,
        uint8_t numFs
    );

    // Wird vom SensorHub/Callback aufgerufen
    void onSensorTrigger(uint8_t sIdx);

    // Startet die FS
    void startFs(uint8_t fsIndex);

private:
    Weiche* _weichen;
    const SteuerungWeichenDefinition* _defs;
    uint8_t _numFs;

    bool isResetSensor(const SteuerungWeichenDefinition& fs, uint8_t sensor);
};
