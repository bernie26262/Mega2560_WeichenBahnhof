#pragma once

// Zuordnung Bahnhof <-> Sensoren

struct BhfSensorMap {
    uint8_t sEinfahrt;    // PulseSensor – Strom AUS
    uint8_t sTimerstart;  // PulseSensor – Timerstart
};

// Index: Bhf 0..3
static const BhfSensorMap BHF_MAP[4] = {
    { 2, 19 },   // Bhf 0
    { 2, 18 },   // Bhf 1
    { 8, 22 },   // Bhf 2
    { 8, 23 }    // Bhf 3
};
