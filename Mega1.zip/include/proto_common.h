#pragma once
#include <Arduino.h>

// ============================================================================
// Gemeinsame Protokolldefinitionen Mega1 / Mega2 / ESP
// ============================================================================

// Welcher Mega ist der Absender?
enum class MegaId : uint8_t {
    MEGA1 = 1,
    MEGA2 = 2
};

// Optionale Protokoll-Versionsinfo (kann im Frame-Header oder Payload genutzt werden)
struct ProtoVersion {
    uint8_t major;
    uint8_t minor;
    uint8_t patch;
};

// CRC16 CCITT (können wir später im I2C-Frame nutzen, aktuell optional)
uint16_t crc16_ccitt(const uint8_t* data, uint16_t len);
