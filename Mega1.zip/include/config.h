#pragma once
#include <Arduino.h>
#include "mega1_pins.h"   // enthält MEGA1_I2C_ADDRESS

// Protokollversion (kann später auch in Payload übernommen werden)
static constexpr uint8_t PROTOCOL_VERSION_MAJOR = 1;
static constexpr uint8_t PROTOCOL_VERSION_MINOR = 0;
static constexpr uint8_t PROTOCOL_VERSION_PATCH = 0;

// Maximale Anzahl Sensoren im Hub (S0..S23)
static constexpr uint8_t MAX_SENSORS     = MEGA1_MAX_SENS;   // 24
static constexpr uint8_t NUM_WEICHEN     = 12;
static constexpr uint8_t NUM_BAHNHOEFE   = 4;

// Gemeinsame Konfigurationsdaten für Mega1







