#pragma once
#include <Arduino.h>

// ------------------------------------------------------------
// SensorKontakt (low-aktiv)
// 
// read() == true → Kontakt aktiv (LOW)
// ------------------------------------------------------------

class SensorKontakt {
public:
    SensorKontakt() {}
    SensorKontakt(uint8_t pin) : m_pin(pin) {}

    void attach(uint8_t pin)
    {
        m_pin = pin;
    }

    void begin()
    {
        if (m_pin == 255) return;
        pinMode(m_pin, INPUT_PULLUP);
    }

    bool read() const
    {
        if (m_pin == 255) return false;
        return (digitalRead(m_pin) == LOW);
    }

private:
    uint8_t m_pin = 255;
};
