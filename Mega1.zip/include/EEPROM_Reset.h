#pragma once
#include <Arduino.h>
#include <EEPROM.h>
#include "config.h"

// Setzt ALLE Weichen-EEPROM-Felder auf 0xFF (= "leer")
inline void resetWeichenEEPROM() {
    for (uint8_t i = 0; i < NUM_WEICHEN; i++) {
        EEPROM.write(EEPROM_WEICHEN_BASE + i, 0xFF);
    }
}
