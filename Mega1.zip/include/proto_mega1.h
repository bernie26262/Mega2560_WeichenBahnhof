#pragma once
#include <Arduino.h>
#include "proto_common.h"

// ============================================================================
//   Mega1 → ESP32 Status-Payload
//   - Sensorhub: Schaltgleise S0..S10 + Timer-Sensoren S18/S19/S22/S23
//   - Weichen W0..W11
//   - Bahnhöfe 0..3 mit Einfahrt- & Timerstatus
//   - Modus Automatik/Manuell
// ============================================================================

// Maximale Anzahl Sensoren, die der SensorHub verwalten kann
// (wir wollen S0..S10 plus S18,S19,S22,S23 abdecken → bis 23)
static const uint8_t MEGA1_MAX_SENS       = 24;   // Indizes 0..23
static const uint8_t MEGA1_MAX_WEICHEN    = 12;   // W0..W11
static const uint8_t MEGA1_MAX_BHF        = 4;    // Bhf 0..3

// Statusflags (werden aus Modus abgeleitet)
enum StatusFlags : uint8_t {
    STATUS_AUTOMATIK = 0x01,
    STATUS_MANUELL   = 0x02
};

// Fahrstraßenstatus (für Web-UI / Diagnose)
enum FahrstrassenState : uint8_t {
    FS_IDLE    = 0,
    FS_RUNNING = 1,
    FS_DONE    = 2,
    FS_ERROR   = 3
};

// ============================================================================
//   Payloadstruktur Mega1
//   Wird 1:1 binär über I2C an den ESP geschickt.
// ============================================================================

struct Mega1StatusPayload
{
    // Kopf / Meta
    uint16_t updateCounter;     // erhöht sich bei jedem Payload-Build
    uint16_t bootId;            // Zufallswert beim Start → Erkennung von Resets
    uint32_t uptimeDiv100;      // millis()/100

    uint8_t  statusFlags;       // STATUS_AUTOMATIK / STATUS_MANUELL
    uint8_t  errorFlags;        // reserviert
    uint8_t  warnFlags;         // reserviert
    uint8_t  modus;             // 0 = Automatik, 1 = Manuell

    // ---------------- Sensorhub ----------------
    // Kontaktbits aller „digitalen“ Sensoren.
    // Wir kodieren hier S0..S23 in einem 32-Bit-Feld.
    uint32_t kontaktBits;                      

    // Triggerzähler für alle Sensoren, die der Hub kennt.
    // Index = Sensor-ID (0..MEGA1_MAX_SENS-1).
    uint16_t triggerCount[MEGA1_MAX_SENS];

    // ---------------- Weichen W0..W11 ----------------
    // Rückmelde-Iststellung (LOW = Abzweig)
    uint16_t weichenIstBits;          // Bit i → Weiche i ist ABZWEIG

    // Sollstellung (ziel)
    uint16_t weichenSollBits;         // Bit i → Ziel = ABBIEGEN

    // Langsamfahr-/Reduktions-Flags
    uint16_t weichenReduktionBits;    // Bit i → Reduktion aktiv

    // ---------------- Fahrstraßen ----------------
    uint8_t aktiveFahrstrasse;        // Index 0..n
    uint8_t fahrstrState;             // FahrstrassenState
    uint8_t reservedFs[2];            // für spätere Erweiterung

    // ---------------- Bahnhöfe 0..3 ----------------
    // Diese Felder kannst du frei mit deinem BahnhofController füllen.
    uint8_t bhfState[MEGA1_MAX_BHF];  // z.B. 0=frei, 1=belegt, 2=Timer, ...
    uint8_t bhfFahrstr[MEGA1_MAX_BHF];// z.B. aktuelle Fahrstraße Richtung Bhf

    // ---------------- NEU: Bhf-Kontaktstatus ----------------
    // Einfahrtkontakte:
    //  Bit0 → Bhf0 Einfahrt aktiv  (S2)
    //  Bit1 → Bhf1 Einfahrt aktiv  (S2)
    //  Bit2 → Bhf2 Einfahrt aktiv  (S8)
    //  Bit3 → Bhf3 Einfahrt aktiv  (S8)
    uint8_t bhfKontaktBits;

    // Timerstartkontakte:
    //  Bit0 → Bhf0 Timerstart aktiv (S19)
    //  Bit1 → Bhf1 Timerstart aktiv (S18)
    //  Bit2 → Bhf2 Timerstart aktiv (S22)
    //  Bit3 → Bhf3 Timerstart aktiv (S23)
    uint8_t bhfTimerBits;
} __attribute__((packed));

// Konstante, falls du die Größe irgendwo brauchst:
static const uint16_t MEGA1_PAYLOAD_SIZE = sizeof(Mega1StatusPayload);
